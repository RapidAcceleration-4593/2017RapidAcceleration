from setuptools import setup

setup(name='luv2see',
      version='0.1',
      description='Rapid Acceleration Team 4593 Vision Library',
      url='https://github.com/Rapid-Acceleration-4593',
      author='Rapid Acceleration Team',
      author_email='julian.brackins@mines.sdsmt.edu',
      license='None',
      packages=['luv2see'],
      zip_safe=False)